const data = [
  {
    "name": "Home made pizza",
    "price": 190,
    "rating": 4.7,
    "delivery_time": "50-79 min",
    "quantity": 1,
    "image_url": ""
  },
  {
    "name": "Tandoori Chicken",
    "price": 184,
    "rating": 4.3,
    "delivery_time": "15-29 min",
    "quantity": 1,
    "image_url": "",
    "discount": "10%"
  },
  {
    "name": "Chilli Chicken",
    "price": 116,
    "rating": 4.1,
    "delivery_time": "30-40 min",
    "quantity": 1,
    "image_url": "",
    "discount": "30%"
  },
  {
    "name": "Veg Burger",
    "price": 99,
    "rating": 4.5,
    "delivery_time": "20-30 min",
    "image_url": "",
    "discount": "30%"
  },
  {
    "name": "Pasta Alfredo",
    "price": 150,
    "rating": 4.2,
    "delivery_time": "25-35 min",
    "image_url": ""
  }
];
const overlay = document.createElement("div");
overlay.id = "overlay";
document.body.appendChild(overlay);
overlay.style.display = "none";


function modal1() {
  console.log("Firing");

  const modal1 = document.getElementById("modal1");

  // Style the overlay
  overlay.style.display = "flex";
  overlay.style.position = "fixed";
  overlay.style.top = "0";
  overlay.style.left = "0";
  overlay.style.width = "100%";
  overlay.style.height = "100%";
  overlay.style.backgroundColor = "rgba(0, 0, 0, 0.5)"; // Semi-black transparency
  overlay.style.zIndex = "9998";
  overlay.style.transition = "opacity 0.3s ease";



  const btn1 = document.getElementById("btn1");
  const btn2 = document.getElementById("btn2");

  btn1.disabled = true;
  btn2.disabled = true;

  modal1.style.display = "flex";
  modal1.style.opacity = "1";
  modal1.style.zIndex = "9999";
}

function modal2() {
  const modal2 = document.getElementById("modal2");
  const btn1 = document.getElementById("btn1");
  const btn2 = document.getElementById("btn2");
  const overlay = document.createElement("div");
  overlay.id = "overlay";

  // Style the overlay
  overlay.style.display = "flex";
  overlay.style.position = "fixed";
  overlay.style.top = "0";
  overlay.style.left = "0";
  overlay.style.width = "100%";
  overlay.style.height = "100%";
  overlay.style.backgroundColor = "rgba(0, 0, 0, 0.5)"; // Semi-black transparency
  overlay.style.zIndex = "9998";
  overlay.style.transition = "opacity 0.3s ease";

  document.body.appendChild(overlay);

  const main = document.getElementsByTagName("main")[0];
  const footer = document.getElementsByTagName("footer")[0];
  const header = document.getElementsByTagName("header")[0];

  btn1.disabled = true;
  btn2.disabled = true;
  modal2.style.display = "flex";
  modal2.style.opacity = "1";
  modal2.style.zIndex = "9999";

}

function modal1close() {
  const modal1 = document.getElementById("modal1");
  modal1.style.display = "none";
  const btn1 = document.getElementById("btn1");
  const btn2 = document.getElementById("btn2");
  const overlay = document.getElementById("overlay");

  overlay.style.display = "none";
  btn1.disabled = false;
  btn2.disabled = false;


}

function cancelModel2() {
  const modal2 = document.getElementById("modal2");
  modal2.style.display = "none";
  const btn1 = document.getElementById("btn1");
  const btn2 = document.getElementById("btn2");
  const overlay = document.getElementById("overlay");

  overlay.style.display = "none";

  btn1.disabled = false;
  btn2.disabled = false;

}




const foodInfo = [
  { id: 1, image_url: './images/slider-1.png', name: 'Pizza', price: 480, rating: 4.5 },
  { id: 2, image_url: './images/slider-2.png', name: 'Burger', price: 450, rating: 4.2 },
  { id: 3, image_url: './images/slider-3.png', name: 'Sushi', price: 470, rating: 4.7 },
  { id: 4, image_url: './images/slider-1.png', name: 'Pasta', price: 450, rating: 4.3 },
  { id: 5, image_url: './images/slider-2.png', name: 'Salad', price: 420, rating: 4.1 }
];

const ImageStruct = document.getElementById('imageSlider');
const sliderContainer = document.getElementById('imageSliderContainer');

ImageStruct.innerHTML = foodInfo.map((ele) => {
  return `
      <div class="imageSlider">
        <div class="image" id="${ele.id}">
          <img src="${ele.image_url}" alt="food" class="image_size" />
          <div class="image_info">
          <p>${ele.name}</p>
          <p>Price: &#8377;${ele.price}</p>
          </div>
          <div class="image_info">
          <p>Rating: ⭐${ele.rating}</p>
          <p>
          <svg width="23" height="21" viewBox="0 0 23 21" fill="none" xmlns="http://www.w3.org/2000/svg">
<rect x="0.5" y="0.5" width="22" height="20" rx="5" fill="#BEBEBE"/>
<rect x="0.5" y="0.5" width="22" height="20" rx="5" fill="#F3BA00"/>
<path d="M11.5991 10.6961V16.1863M6.04956 10.6961H11.5991H6.04956ZM17.1487 10.6961H11.5991H17.1487ZM11.5991 10.6961V5.20587V10.6961Z" stroke="white" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
</p>

          </div>
        </div>
      </div>
    `;
}).join('');

const moveLeftBtn = document.getElementById('moveLeft');
const moveRightBtn = document.getElementById('moveRight');

let scrollPosition = 0;
const itemWidth = 620; // Width of each item including margin

// Move Left
moveLeftBtn.addEventListener('click', () => {
  scrollPosition = Math.min(scrollPosition + itemWidth, 0); // Prevent overscrolling to the left
  ImageStruct.style.transform = `translateX(${scrollPosition}px)`;
});

// Move Right
moveRightBtn.addEventListener('click', () => {
  const maxScroll = -(itemWidth * (foodInfo.length - Math.floor(sliderContainer.offsetWidth / itemWidth)));
  scrollPosition = Math.max(scrollPosition - itemWidth, maxScroll); // Prevent overscrolling to the right
  ImageStruct.style.transform = `translateX(${scrollPosition}px)`;
});